import React, { useState } from 'react';
import { Menu, X, Share2, ShoppingCart, Star, Users, Heart, Flag } from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);

  const handlePurchase = () => {
    window.open('https://go.disruptybr.com.br/lqqry062lq', '_blank');
  };

  const handleShare = (platform: string) => {
    const url = window.location.href;
    const text = "Esquemas de corrupção do PT expostos - A verdade que você precisa saber!";
    
    switch (platform) {
      case 'facebook':
        window.open(`https://facebook.com/sharer/sharer.php?u=${url}`, '_blank');
        break;
      case 'twitter':
        window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
        break;
      case 'whatsapp':
        window.open(`https://wa.me/?text=${text} ${url}`, '_blank');
        break;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-green-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-12 h-8 bg-gradient-to-r from-green-600 via-yellow-400 to-blue-700 rounded-sm flex items-center justify-center">
                <Flag className="w-6 h-4 text-white" />
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-green-700">Brasil Verdade</h1>
                <p className="text-xs text-blue-700 font-medium">A informação que o Brasil precisa</p>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-gray-700 hover:text-green-600 font-medium transition-colors">Política</a>
              <a href="#" className="text-gray-700 hover:text-green-600 font-medium transition-colors">Economia</a>
              <a href="#" className="text-gray-700 hover:text-green-600 font-medium transition-colors">Justiça</a>
              <a href="#" className="text-gray-700 hover:text-green-600 font-medium transition-colors">Brasil</a>
              <a href="#" className="text-gray-700 hover:text-green-600 font-medium transition-colors">Opinião</a>
            </nav>

            {/* Mobile menu button */}
            <button 
              className="md:hidden p-2"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden pb-4 border-t border-gray-200 mt-4 pt-4">
              <div className="flex flex-col space-y-2">
                <a href="#" className="text-gray-700 hover:text-green-600 font-medium py-2">Política</a>
                <a href="#" className="text-gray-700 hover:text-green-600 font-medium py-2">Economia</a>
                <a href="#" className="text-gray-700 hover:text-green-600 font-medium py-2">Justiça</a>
                <a href="#" className="text-gray-700 hover:text-green-600 font-medium py-2">Brasil</a>
                <a href="#" className="text-gray-700 hover:text-green-600 font-medium py-2">Opinião</a>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Banner */}
      <section className="bg-gradient-to-r from-blue-700 via-green-600 to-yellow-500 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="inline-flex items-center bg-red-600 text-white px-4 py-2 rounded-full text-sm font-bold mb-4">
              <span className="animate-pulse">🔴</span>
              <span className="ml-2">URGENTE</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-bold mb-4">
              Esquemas de corrupção do PT expostos
            </h1>
            <p className="text-xl md:text-2xl opacity-90 mb-6">
              A verdade que o STF não quer que você veja
            </p>
            <div className="flex justify-center items-center space-x-4 text-sm">
              <span>⏰ Acesse antes que seja censurado</span>
              <span>🇧🇷 Pela verdade do Brasil</span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Article Content */}
          <div className="lg:col-span-2">
            <article className="bg-white">
              <div className="mb-6">
                <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                  <span>Por Redação Brasil Verdade</span>
                  <span>•</span>
                  <span>Hoje, 15h30</span>
                  <span>•</span>
                  <span className="text-green-600 font-medium">Política</span>
                </div>
                
                <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 leading-tight">
                  Esquemas de corrupção do PT expostos: o que a grande mídia e o STF não querem que você saiba
                </h1>
                
                <p className="text-xl text-gray-700 mb-6 leading-relaxed">
                  Conheça detalhes exclusivos e ajude a fortalecer o Brasil com um preço simbólico. Metade da arrecadação será doada para instituições carentes.
                </p>
              </div>

              {/* Social Share */}
              <div className="flex items-center space-x-4 mb-8 p-4 bg-green-50 rounded-lg">
                <span className="text-green-700 font-medium">Compartilhe a verdade:</span>
                <button 
                  onClick={() => handleShare('facebook')}
                  className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Facebook</span>
                </button>
                <button 
                  onClick={() => handleShare('whatsapp')}
                  className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                >
                  <Share2 className="w-4 h-4" />
                  <span>WhatsApp</span>
                </button>
              </div>

              {/* Article Body */}
              <div className="prose prose-lg max-w-none">
                <p className="text-gray-800 leading-relaxed mb-6">
                  Em uma investigação exclusiva que durou meses, nossa equipe de jornalistas conseguiu acesso a documentos e informações que revelam a verdadeira extensão dos esquemas de corrupção que marcaram os governos petistas no Brasil.
                </p>

                <p className="text-gray-800 leading-relaxed mb-6">
                  <strong className="text-green-700">O que você vai descobrir neste relatório exclusivo:</strong>
                </p>

                <ul className="list-disc pl-6 mb-6 space-y-2 text-gray-800">
                  <li>Documentos nunca antes revelados sobre o Mensalão e Petrolão</li>
                  <li>Conexões entre políticos do PT e esquemas milionários</li>
                  <li>Como o dinheiro público foi desviado por décadas</li>
                  <li>Evidências que foram ocultadas da população brasileira</li>
                  <li>A rede de proteção que impediu investigações completas</li>
                </ul>

                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-6 my-8">
                  <p className="text-yellow-800 font-medium">
                    ⚠️ <strong>Importante:</strong> Este conteúdo foi compilado com base em documentos públicos, processos judiciais e investigações jornalísticas. Acesse agora antes que tentativas de censura possam limitar sua distribuição.
                  </p>
                </div>

                <p className="text-gray-800 leading-relaxed mb-6">
                  Nosso compromisso é com a transparência e a verdade. Por isso, disponibilizamos este material por um valor simbólico de apenas R$ 12,90 - valor que cobre os custos de produção e permite que metade seja destinada a instituições que ajudam o Brasil.
                </p>

                <p className="text-gray-800 leading-relaxed mb-8">
                  <strong className="text-blue-700">Junte-se aos mais de 50.000 brasileiros que já têm acesso à verdade completa.</strong> Sua contribuição fortalece o jornalismo independente e ajuda instituições carentes em todo o país.
                </p>
              </div>
            </article>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Purchase Box */}
            <div className="bg-gradient-to-br from-green-600 to-blue-700 text-white rounded-xl p-6 mb-8 shadow-xl">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold mb-2">🇧🇷 Acesso Exclusivo</h3>
                <p className="text-green-100">Esquemas de Corrupção do PT</p>
              </div>

              <div className="space-y-4 mb-6">
                <div className="flex items-center space-x-3">
                  <span className="text-yellow-300">✅</span>
                  <span>Relatório completo (120 páginas)</span>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="text-yellow-300">✅</span>
                  <span>Documentos exclusivos</span>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="text-yellow-300">✅</span>
                  <span>Acesso vitalício</span>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="text-yellow-300">✅</span>
                  <span>Atualizações gratuitas</span>
                </div>
              </div>

              <div className="text-center mb-6">
                <div className="text-3xl font-bold mb-2">R$ 12,90</div>
                <p className="text-green-100 text-sm">Preço simbólico para ajudar o Brasil</p>
                <p className="text-yellow-300 text-xs mt-1">50% doado para instituições carentes</p>
              </div>

              <button 
                onClick={handlePurchase}
                className="w-full bg-yellow-400 text-blue-900 font-bold py-4 px-6 rounded-lg hover:bg-yellow-300 transition-colors flex items-center justify-center space-x-2 mb-4"
              >
                <ShoppingCart className="w-5 h-5" />
                <span>ADQUIRIR AGORA</span>
              </button>

              <div className="text-center text-sm space-y-1">
                <p className="text-green-100">✅ Pagamento 100% seguro</p>
                <p className="text-green-100">✅ Acesso imediato</p>
                <p className="text-green-100">✅ Garantia de 7 dias</p>
              </div>
            </div>

            {/* Testimonials */}
            <div className="bg-white border border-gray-200 rounded-lg p-6 mb-8">
              <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                <Users className="w-5 h-5 text-green-600 mr-2" />
                O que dizem nossos leitores
              </h3>
              
              <div className="space-y-4">
                <div className="border-l-4 border-green-500 pl-4">
                  <p className="text-gray-700 text-sm mb-2">"Finalmente a verdade veio à tona. Material impecável e bem documentado."</p>
                  <p className="text-green-600 font-medium text-sm">— João Silva, São Paulo</p>
                  <div className="flex text-yellow-400 text-xs mt-1">
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                  </div>
                </div>

                <div className="border-l-4 border-blue-500 pl-4">
                  <p className="text-gray-700 text-sm mb-2">"Informações que nunca vi na grande mídia. Vale cada centavo investido."</p>
                  <p className="text-blue-600 font-medium text-sm">— Maria Santos, Rio de Janeiro</p>
                  <div className="flex text-yellow-400 text-xs mt-1">
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                  </div>
                </div>

                <div className="border-l-4 border-yellow-500 pl-4">
                  <p className="text-gray-700 text-sm mb-2">"Todo brasileiro deveria ter acesso a essas informações. Parabéns pelo trabalho!"</p>
                  <p className="text-yellow-600 font-medium text-sm">— Carlos Oliveira, Minas Gerais</p>
                  <div className="flex text-yellow-400 text-xs mt-1">
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                    <Star className="w-3 h-3 fill-current" />
                  </div>
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
              <h3 className="text-lg font-bold text-blue-900 mb-4">🇧🇷 Impacto Brasil Verdade</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-blue-700">Leitores alcançados:</span>
                  <span className="font-bold text-blue-900">+50.000</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-blue-700">Instituições apoiadas:</span>
                  <span className="font-bold text-blue-900">25</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-blue-700">Valor doado:</span>
                  <span className="font-bold text-blue-900">R$ 47.850</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Logo and Description */}
            <div className="md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-12 h-8 bg-gradient-to-r from-green-600 via-yellow-400 to-blue-700 rounded-sm flex items-center justify-center">
                  <Flag className="w-6 h-4 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-green-400">Brasil Verdade</h3>
                  <p className="text-blue-300 text-sm">A informação que o Brasil precisa</p>
                </div>
              </div>
              <p className="text-gray-300 mb-4">
                Comprometidos com a transparência, a verdade e o fortalecimento dos valores brasileiros. 
                Jornalismo independente a serviço da nação.
              </p>
              <div className="flex items-center space-x-2 text-sm text-yellow-300">
                <Heart className="w-4 h-4" />
                <span>Feito com amor pelo Brasil</span>
              </div>
            </div>

            {/* Links */}
            <div>
              <h4 className="text-lg font-bold mb-4 text-green-400">Institucional</h4>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#" className="hover:text-white transition-colors">Sobre nós</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Nossa missão</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Código de ética</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Transparência</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Políticas de privacidade</a></li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="text-lg font-bold mb-4 text-blue-300">Contato</h4>
              <ul className="space-y-2 text-gray-300">
                <li>📧 contato@brasilverdade.com.br</li>
                <li>📱 (11) 99999-9999</li>
                <li>📍 São Paulo, SP</li>
                <li><a href="#" className="hover:text-white transition-colors">Fale conosco</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Denúncias</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-700 mt-8 pt-8 text-center">
            <p className="text-gray-400 text-sm mb-2">
              © 2024 Brasil Verdade. Todos os direitos reservados.
            </p>
            <p className="text-yellow-300 text-sm font-medium">
              🇧🇷 Pela verdade, transparência e grandeza do Brasil 🇧🇷
            </p>
          </div>
        </div>
      </footer>

      {/* Purchase Modal */}
      {showPurchaseModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full p-6">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">🇧🇷 Adquirir Relatório</h3>
              <p className="text-gray-600">Esquemas de Corrupção do PT</p>
            </div>

            <div className="space-y-4 mb-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">R$ 12,90</div>
                <p className="text-sm text-gray-600">Pagamento único • Acesso vitalício</p>
              </div>

              <div className="bg-green-50 p-4 rounded-lg">
                <p className="text-green-800 text-sm text-center">
                  <strong>50% será doado</strong> para instituições carentes brasileiras
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <button 
                onClick={() => window.open('https://go.disruptybr.com.br/lqqry062lq', '_blank')}
                className="w-full bg-green-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-green-700 transition-colors"
              >
                Pagar com PIX
              </button>
              <button 
                onClick={() => window.open('https://go.disruptybr.com.br/lqqry062lq', '_blank')}
                className="w-full bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Cartão de Crédito
              </button>
              <button 
                onClick={() => setShowPurchaseModal(false)}
                className="w-full bg-gray-200 text-gray-700 font-bold py-3 px-6 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Cancelar
              </button>
            </div>

            <p className="text-xs text-gray-500 text-center mt-4">
              Pagamento 100% seguro • Garantia de 7 dias
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;