import React from 'react';
import Header from './components/Header';
import Hook from './components/Hook';
import Problem from './components/Problem';
import KeyContent from './components/KeyContent';
import Authority from './components/Authority';
import Transformation from './components/Transformation';
import Offer from './components/Offer';
import Testimonials from './components/Testimonials';
import CTA from './components/CTA';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <Hook />
      <Problem />
      <KeyContent />
      <Authority />
      <Transformation />
      <Offer />
      <Testimonials />
      <CTA />
      <Footer />
    </div>
  );
}

export default App;