import React from 'react';
import { Quote, Star, User } from 'lucide-react';

export default function Testimonials() {
  const testimonials = [
    {
      name: "Maria Souza",
      location: "São Paulo, SP", 
      text: "Eu não fazia ideia da dimensão dos escândalos. Esse material é um verdadeiro raio-X da corrupção no Brasil.",
      rating: 5
    },
    {
      name: "Rafael Lima",
      location: "Goiânia, GO",
      text: "As provas, os documentos e os links me deram segurança para entender os fatos. Recomendo pra quem quer ter uma visão clara do que aconteceu.",
      rating: 5
    },
    {
      name: "Ana Carolina",
      location: "Porto Alegre, RS",
      text: "Finalmente encontrei um conteúdo organizado, com provas reais e sem enrolação. Agora posso debater com base.",
      rating: 5
    }
  ];

  return (
    <section className="bg-gray-50 py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
            O Que Outros Estão Dizendo
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Pessoas que já tiveram acesso ao material completo compartilham suas experiências.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-lg">
              <div className="flex justify-center mb-4">
                <Quote className="w-8 h-8 text-red-500" />
              </div>
              
              <div className="flex justify-center mb-4">
                {[1,2,3,4,5].map((star) => (
                  <Star 
                    key={star} 
                    className={`w-5 h-5 ${star <= testimonial.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'}`} 
                  />
                ))}
              </div>
              
              <p className="text-gray-700 mb-6 italic text-center">
                "{testimonial.text}"
              </p>
              
              <div className="flex items-center justify-center gap-3">
                <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-gray-500" />
                </div>
                <div>
                  <p className="font-bold text-gray-900">{testimonial.name}</p>
                  <p className="text-gray-600 text-sm">{testimonial.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 bg-blue-50 p-8 rounded-lg text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            Junte-se a Centenas de Pessoas Bem Informadas
          </h3>
          <p className="text-gray-700 mb-6">
            Pessoas que decidiram buscar informações completas e verificadas sobre os fatos que marcaram a política brasileira.
          </p>
          <div className="flex justify-center gap-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">500+</div>
              <div className="text-gray-600 text-sm">Leitores Satisfeitos</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">4.9</div>
              <div className="text-gray-600 text-sm">Avaliação Média</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">98%</div>
              <div className="text-gray-600 text-sm">Recomendariam</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}