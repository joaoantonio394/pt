import React from 'react';
import { Shield, Mail, Phone } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Shield className="w-6 h-6 text-red-500" />
              <h3 className="text-xl font-bold">Informação Verificada</h3>
            </div>
            <p className="text-gray-400">
              Comprometidos com a transparência e a verificação de todas as informações apresentadas.
            </p>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">Contato</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-red-500" />
                <span className="text-gray-400">contato@verdadepolitica.com.br</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-red-500" />
                <span className="text-gray-400">(62) 9 9999-9999</span>
              </div>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">Garantias</h3>
            <ul className="space-y-2 text-gray-400">
              <li>• Informações verificadas</li>
              <li>• Documentação oficial</li>
              <li>• Garantia de satisfação</li>
              <li>• Suporte completo</li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400">
            © 2024 - Todos os direitos reservados. Material baseado em fontes públicas e documentos oficiais.
          </p>
        </div>
      </div>
    </footer>
  );
}