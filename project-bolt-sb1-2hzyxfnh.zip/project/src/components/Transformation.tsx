import React from 'react';
import { CheckCircle, Brain, MessageCircle, Shield } from 'lucide-react';

export default function Transformation() {
  const benefits = [
    {
      icon: <Brain className="w-6 h-6 text-green-500" />,
      title: "Compreensão Completa",
      description: "Tenha uma visão clara e cronológica de todos os casos e suas conexões"
    },
    {
      icon: <MessageCircle className="w-6 h-6 text-green-500" />,
      title: "Argumentos Sólidos",
      description: "Participe de debates com fatos documentados e informações verificadas"
    },
    {
      icon: <Shield className="w-6 h-6 text-green-500" />,
      title: "Proteção Contra Fake News",
      description: "Diferencie informações verdadeiras de narrativas distorcidas"
    }
  ];

  return (
    <section className="bg-gradient-to-r from-green-50 to-blue-50 py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
            A Transformação que Você Terá
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Ao ter acesso a este material completo, você vai experimentar uma mudança significativa na sua compreensão política.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {benefits.map((benefit, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-lg text-center">
              <div className="flex justify-center mb-4">
                {benefit.icon}
              </div>
              <h3 className="text-xl font-bold mb-3 text-gray-900">{benefit.title}</h3>
              <p className="text-gray-700">{benefit.description}</p>
            </div>
          ))}
        </div>
        
        <div className="bg-white p-8 rounded-lg shadow-lg">
          <h3 className="text-2xl font-bold text-center mb-6 text-gray-900">
            O Que Você Vai Conseguir Fazer
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 mt-1" />
                <p className="text-gray-700">Entender o panorama completo dos escândalos</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 mt-1" />
                <p className="text-gray-700">Identificar conexões entre diferentes casos</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 mt-1" />
                <p className="text-gray-700">Formar sua própria opinião baseada em fatos</p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 mt-1" />
                <p className="text-gray-700">Debater com argumentos sólidos e documentados</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 mt-1" />
                <p className="text-gray-700">Estar preparado para discussões políticas</p>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="w-5 h-5 text-green-500 mt-1" />
                <p className="text-gray-700">Compartilhar informações verificadas</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}