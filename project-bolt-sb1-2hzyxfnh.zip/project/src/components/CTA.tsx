import React from 'react';
import { Clock, Shield, CheckCircle } from 'lucide-react';

export default function CTA() {
  return (
    <section className="bg-gradient-to-r from-red-600 to-red-700 text-white py-16 px-4">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-6">
          Não Perca Esta Oportunidade
        </h2>
        <p className="text-xl mb-8 text-red-100">
          Acesso completo a informações que foram mantidas longe do público por anos.
        </p>
        
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-red-500 p-6 rounded-lg">
            <CheckCircle className="w-8 h-8 mx-auto mb-3" />
            <h3 className="font-bold mb-2">Acesso Imediato</h3>
            <p className="text-sm text-red-100">Disponível logo após a confirmação</p>
          </div>
          <div className="bg-red-500 p-6 rounded-lg">
            <Shield className="w-8 h-8 mx-auto mb-3" />
            <h3 className="font-bold mb-2">Garantia Total</h3>
            <p className="text-sm text-red-100">7 dias para avaliar o material</p>
          </div>
          <div className="bg-red-500 p-6 rounded-lg">
            <Clock className="w-8 h-8 mx-auto mb-3" />
            <h3 className="font-bold mb-2">Oferta Limitada</h3>
            <p className="text-sm text-red-100">Preço promocional por tempo limitado</p>
          </div>
        </div>
        
        <div className="bg-white bg-opacity-20 backdrop-blur-sm p-8 rounded-lg mb-8">
          <h3 className="text-2xl font-bold mb-4">Últimas Horas da Promoção</h3>
          <div className="flex justify-center gap-4 mb-6">
            <div className="text-center">
              <div className="text-3xl font-bold">12</div>
              <div className="text-sm">Horas</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">:</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">35</div>
              <div className="text-sm">Minutos</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">:</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">42</div>
              <div className="text-sm">Segundos</div>
            </div>
          </div>
          <p className="text-red-100">
            Apenas para os primeiros 200 interessados
          </p>
        </div>
        
        <div className="mb-6">
          <span className="text-red-200 text-lg line-through">De R$ 97,00</span>
          <span className="text-4xl font-bold ml-4">Por apenas R$ 16,90</span>
        </div>
        
        <a 
          href="https://pay.kirvano.com/5665bdd8-a727-45a6-8c3b-67b6901133ab"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-white text-red-600 px-12 py-4 rounded-lg font-bold text-xl hover:bg-gray-100 transition-all duration-300 transform hover:scale-105 shadow-lg"
        >
          QUERO VER A VERDADE AGORA
        </a>
        
        <p className="mt-4 text-red-100 text-sm">
          Pagamento seguro • Acesso imediato • Garantia de 7 dias
        </p>
      </div>
    </section>
  );
}