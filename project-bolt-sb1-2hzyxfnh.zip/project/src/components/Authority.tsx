import React from 'react';
import { Award, FileCheck, Scale, Users } from 'lucide-react';

export default function Authority() {
  return (
    <section className="bg-gray-900 text-white py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Baseado em Fontes Oficiais
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Todas as informações são baseadas em documentos oficiais, depoimentos registrados e decisões judiciais.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="bg-red-500 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <FileCheck className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-lg font-bold mb-2">Documentos Oficiais</h3>
            <p className="text-gray-400 text-sm">Processos, inquéritos e documentos do judiciário</p>
          </div>
          
          <div className="text-center">
            <div className="bg-red-500 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-lg font-bold mb-2">Depoimentos</h3>
            <p className="text-gray-400 text-sm">Declarações registradas e delações premiadas</p>
          </div>
          
          <div className="text-center">
            <div className="bg-red-500 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Scale className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-lg font-bold mb-2">Decisões Judiciais</h3>
            <p className="text-gray-400 text-sm">Sentenças e acórdãos dos tribunais</p>
          </div>
          
          <div className="text-center">
            <div className="bg-red-500 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Award className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-lg font-bold mb-2">Fontes Verificadas</h3>
            <p className="text-gray-400 text-sm">Apenas informações de fontes confiáveis</p>
          </div>
        </div>
        
        <div className="mt-12 bg-gray-800 p-8 rounded-lg">
          <h3 className="text-2xl font-bold text-center mb-6">Exemplos de Documentos Incluídos</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="bg-gray-700 h-32 rounded-lg mb-4 flex items-center justify-center">
                <FileCheck className="w-12 h-12 text-gray-500" />
              </div>
              <p className="text-sm text-gray-400">Inquéritos e Processos</p>
            </div>
            <div className="text-center">
              <div className="bg-gray-700 h-32 rounded-lg mb-4 flex items-center justify-center">
                <FileCheck className="w-12 h-12 text-gray-500" />
              </div>
              <p className="text-sm text-gray-400">Planilhas e Relatórios</p>
            </div>
            <div className="text-center">
              <div className="bg-gray-700 h-32 rounded-lg mb-4 flex items-center justify-center">
                <FileCheck className="w-12 h-12 text-gray-500" />
              </div>
              <p className="text-sm text-gray-400">Transcrições</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}