import React from 'react';
import { Shield, FileText, Users, Clock } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-gradient-to-r from-slate-900 to-slate-800 text-white py-16 px-4">
      <div className="max-w-4xl mx-auto text-center">
        <div className="flex justify-center mb-6">
          <Shield className="w-16 h-16 text-red-500" />
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
          <span className="text-red-500">Corrupção do PT:</span>
          <br />
          <span className="text-white">Tudo o Que Nunca Te Contaram</span>
        </h1>
        
        <p className="text-xl md:text-2xl mb-8 text-gray-300 max-w-3xl mx-auto">
          A verdade escondida por anos sob o tapete do poder finalmente revelada. Descubra os bastidores dos maiores escândalos da política brasileira — com provas, documentos oficiais e links de reportagens reais.
        </p>
        
        <div className="flex flex-wrap justify-center gap-6 mb-8">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-red-500" />
            <span className="text-sm">Documentos Exclusivos</span>
          </div>
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-red-500" />
            <span className="text-sm">Análise Completa</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-red-500" />
            <span className="text-sm">Acesso Imediato</span>
          </div>
        </div>
        
        <a 
          href="https://pay.kirvano.com/5665bdd8-a727-45a6-8c3b-67b6901133ab"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-bold text-lg transition-all duration-300 transform hover:scale-105 shadow-lg"
        >
          QUERO VER A VERDADE AGORA
        </a>
      </div>
    </header>
  );
}