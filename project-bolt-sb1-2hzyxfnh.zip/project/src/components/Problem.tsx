import React from 'react';
import { Eye, EyeOff, Newspaper, Users } from 'lucide-react';

export default function Problem() {
  return (
    <section className="bg-gray-50 py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
            O Problema que Você Enfrenta
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Informações fragmentadas, versões contraditórias e uma névoa de desinformação que impede você de ter o quadro completo.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-white p-8 rounded-lg shadow-lg">
            <div className="flex items-center mb-4">
              <EyeOff className="w-8 h-8 text-red-500 mr-3" />
              <h3 className="text-xl font-bold text-gray-900">Informações Ocultadas</h3>
            </div>
            <p className="text-gray-700">
              Documentos importantes e evidências que nunca chegaram ao conhecimento público de forma organizada e clara.
            </p>
          </div>
          
          <div className="bg-white p-8 rounded-lg shadow-lg">
            <div className="flex items-center mb-4">
              <Newspaper className="w-8 h-8 text-red-500 mr-3" />
              <h3 className="text-xl font-bold text-gray-900">Cobertura Fragmentada</h3>
            </div>
            <p className="text-gray-700">
              Notícias espalhadas, análises superficiais e uma cronologia confusa que dificulta a compreensão dos fatos.
            </p>
          </div>
          
          <div className="bg-white p-8 rounded-lg shadow-lg">
            <div className="flex items-center mb-4">
              <Users className="w-8 h-8 text-red-500 mr-3" />
              <h3 className="text-xl font-bold text-gray-900">Desinformação</h3>
            </div>
            <p className="text-gray-700">
              Versões conflitantes e narrativas que confundem mais do que esclarecem, deixando você sem saber em quem confiar.
            </p>
          </div>
          
          <div className="bg-white p-8 rounded-lg shadow-lg">
            <div className="flex items-center mb-4">
              <Eye className="w-8 h-8 text-red-500 mr-3" />
              <h3 className="text-xl font-bold text-gray-900">Falta de Transparência</h3>
            </div>
            <p className="text-gray-700">
              Processos complexos, linguagem técnica e informações espalhadas em centenas de fontes diferentes.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}