import React from 'react';
import { Star, Download, Video, FileText, Gift } from 'lucide-react';

export default function Offer() {
  return (
    <section className="bg-white py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
            A Verdade Oculta: Os Escândalos do PT com Provas, Documentos e Links Reais
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Acesso completo ao material organizado com provas, documentos oficiais e links para reportagens reais.
          </p>
        </div>
        
        <div className="bg-gradient-to-r from-red-50 to-orange-50 p-8 rounded-lg border-2 border-red-200 mb-8">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Pacote Completo</h3>
            <div className="flex justify-center items-center gap-2 mb-4">
              {[1,2,3,4,5].map((star) => (
                <Star key={star} className="w-5 h-5 text-yellow-500 fill-current" />
              ))}
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <FileText className="w-6 h-6 text-red-500 mt-1" />
                <div>
                  <h4 className="font-bold text-gray-900">E-book Completo</h4>
                  <p className="text-gray-700 text-sm">Análise detalhada dos escândalos com links e documentação oficial</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Download className="w-6 h-6 text-red-500 mt-1" />
                <div>
                  <h4 className="font-bold text-gray-900">Arquivos Extras</h4>
                  <p className="text-gray-700 text-sm">Links diretos para sentenças, reportagens e documentos oficiais</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Video className="w-6 h-6 text-red-500 mt-1" />
                <div>
                  <h4 className="font-bold text-gray-900">Timeline Interativa</h4>
                  <p className="text-gray-700 text-sm">Cronologia visual dos eventos</p>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="bg-yellow-100 p-4 rounded-lg border-l-4 border-yellow-500">
                <div className="flex items-start gap-3">
                  <Gift className="w-6 h-6 text-yellow-600 mt-1" />
                  <div>
                    <h4 className="font-bold text-yellow-800">Bônus Exclusivos</h4>
                    <ul className="text-yellow-700 text-sm mt-2 space-y-1">
                      <li>• Checklist dos Escândalos</li>
                      <li>• Linha do Tempo Interativa</li>
                      <li>• Guia Rápido para Identificar Fake News</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-green-50 p-6 rounded-lg border-2 border-green-200 mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold">✓</span>
            </div>
            <h3 className="text-xl font-bold text-green-800">Garantia de Satisfação</h3>
          </div>
          <p className="text-green-700 text-center">
            Se você não ficar completamente satisfeito com o material, 
            devolvemos 100% do seu dinheiro em até 7 dias. Sem perguntas, sem complicações.
          </p>
        </div>
        
        <div className="text-center">
          <div className="mb-4">
            <span className="text-gray-500 text-lg line-through">De R$ 97,00</span>
            <span className="text-3xl font-bold text-red-600 ml-4">Por apenas R$ 16,90</span>
          </div>
          <a 
            href="https://pay.kirvano.com/5665bdd8-a727-45a6-8c3b-67b6901133ab"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-red-600 hover:bg-red-700 text-white px-12 py-4 rounded-lg font-bold text-xl transition-all duration-300 transform hover:scale-105 shadow-lg"
          >
            QUERO VER A VERDADE AGORA
          </a>
          <p className="text-gray-600 mt-4 text-sm">
            Acesso imediato após a confirmação do pagamento
          </p>
        </div>
      </div>
    </section>
  );
}