import React from 'react';
import { AlertTriangle, TrendingUp } from 'lucide-react';

export default function Hook() {
  return (
    <section className="bg-white py-16 px-4">
      <div className="max-w-4xl mx-auto text-center">
        <div className="flex justify-center mb-6">
          <AlertTriangle className="w-12 h-12 text-red-500" />
        </div>
        
        <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
          Você sabia que mais de <span className="text-red-600">R$ 42 bilhões</span> foram desviados de estatais e órgãos públicos em esquemas ligados ao Partido dos Trabalhadores?
        </h2>
        
        <p className="text-xl text-gray-700 mb-8 max-w-3xl mx-auto">
          Esta é apenas a ponta do iceberg dos maiores escândalos de corrupção da história política brasileira.
        </p>
        
        <div className="bg-red-50 border-l-4 border-red-500 p-6 rounded-r-lg max-w-3xl mx-auto">
          <div className="flex items-start">
            <TrendingUp className="w-6 h-6 text-red-500 mt-1 mr-3" />
            <div className="text-left">
              <p className="font-semibold text-red-800 mb-2">Pergunta Retórica Poderosa:</p>
              <p className="text-red-700">
                "Por que a mídia parou de falar sobre os maiores escândalos de corrupção do país?"
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}