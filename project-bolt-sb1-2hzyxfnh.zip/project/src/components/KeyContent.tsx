import React from 'react';
import { Check, FileText, Calendar, DollarSign } from 'lucide-react';

export default function KeyContent() {
  const scandals = [
    {
      title: "Mensalão",
      description: "Um dos primeiros grandes esquemas envolvendo o PT no governo Lula. Parlamentares recebiam mesadas mensais para votar a favor do governo. Vários membros da cúpula petista foram condenados pelo STF.",
      amount: "R$ 55 milhões",
      year: "2003-2005",
      document: "Ação Penal 470 - STF"
    },
    {
      title: "Lava Jato / Petrolão", 
      description: "O maior escândalo de corrupção da história do Brasil. Envolveu empreiteiras como Odebrecht e OAS, políticos, diretores da Petrobras e o ex-presidente Lula.",
      amount: "R$ 42 bilhões",
      year: "2004-2016",
      document: "Valor Econômico - Lava Jato e os bilhões desviados"
    },
    {
      title: "Caso do Sítio de Atibaia",
      description: "Lula foi condenado por receber reformas bancadas por empreiteiras em um sítio frequentado por ele e sua família. A sentença foi posteriormente anulada por questões processuais, mas os fatos seguem documentados.",
      amount: "R$ 1,1 milhão",
      year: "2010-2014",
      document: "TRF-4 - Processo 50465129420164047000"
    }
  ];

  return (
    <section className="bg-white py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-900">
            O Que Você Vai Descobrir
          </h2>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Uma análise completa e documentada dos principais casos, com provas, valores e cronologia detalhada.
          </p>
        </div>
        
        <div className="space-y-8">
          {scandals.map((scandal, index) => (
            <div key={index} className="bg-gray-50 p-8 rounded-lg border-l-4 border-red-500">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                <h3 className="text-2xl font-bold text-gray-900 mb-2 md:mb-0">
                  {scandal.title}
                </h3>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-red-500" />
                    <span className="font-bold text-red-600">{scandal.amount}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-gray-500" />
                    <span className="text-gray-600">{scandal.year}</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-700 mb-4">{scandal.description}</p>
              <div className="flex items-center gap-2">
                <Check className="w-5 h-5 text-green-500" />
                <span className="text-sm text-gray-600">📄 {scandal.document}</span>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 bg-red-50 p-8 rounded-lg">
          <div className="flex items-start">
            <FileText className="w-8 h-8 text-red-500 mt-1 mr-4" />
            <div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Documentação Completa</h3>
              <p className="text-gray-700">
                Todos os casos incluem links para documentos oficiais, sentenças judiciais, 
                reportagens verificadas e uma cronologia detalhada dos acontecimentos.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}